This file contains some note to the supplementary material of the paper entitled “Grammar rules for the isiZulu complex verb”, submitted to Southern African Linguistics and Applied Language Studies.


Inputting the CFG of the zuluVerb paper, into jflap8-beta (note version!).

Some of the variables are named differently because it has to be single-character in JFlap. the following modifications cf the variable names in the paper have been made:
pre = A
vr = R
post = B
npre = C
ns = D
c = F
a = G
r = H
p = I
ppre = J
pl = K
st = L
wh = N
excl = E
cont = Y

The final version is zuverbCFGwPost2PoliteStative1WH2ad.jflap

Other files

The screenshots in the finalCFGtesting directory are from our grammar.
The screenshots in the zuluMorphAALS sub-directory show the outputs of the FSM from Pretorius & Bosch.


